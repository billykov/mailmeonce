/*!
 * jQuery isjQuery - v0.4 - 2/13/2010
 * http://benalman.com/projects/jquery-misc-plugins/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
jQuery.isjQuery=function(r){return r&&r.hasOwnProperty&&r instanceof jQuery};